package project;

public class Appoint {
	int time;
	patient p;
}
