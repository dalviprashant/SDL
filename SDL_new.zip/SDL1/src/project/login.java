package project;


 class login {
	protected String user,pass;
	login()
	{
		user=null;
		pass=null;
	}
	
}