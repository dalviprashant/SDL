package project;

class Appoint_doc {

	int time;
	String doc_name;
	int doc_id;
	String address;
	char status;
	Appoint_doc()
	{
		status='n';
	}
}
